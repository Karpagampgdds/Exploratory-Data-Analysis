library(readr)
setwd("C:/Users/d.raj/Desktop/Upgrad/Gramener case study/loan")
loan <- read.csv("loan.csv")
View(loan)

########################
#Data clean up#
########################

# Upon running View(loan_summary) and looking at the data, it appears that most of the 
# columns are having values as NA.
# Eleminating these columns to reduce the data frame size.

install.packages("janitor")
library(janitor)
install.packages("stringr")
library(stringr)
loan_data <- remove_empty(loan,"cols")

# loan_data is the data frame will be used from here for the analysis.

# The variable "term" is stored as character. From Data_Dictionary, this variable indicates the term for the loan to repay back. Let's check the unique obersation from this variable.
unique(loan_data$term)
# Unique values are "36 months" "60 months". Let's convert this to number data type so that it will easy to plot the data for the analysis.
loan_data$term <- str_replace(loan_data$term, "months", "")
loan_data$term <- as.numeric(loan_data$term)


# The variables int_rate, revol_util is stored as character. If we can remove % from it, they can be converted as number and easy for analysis.
loan_data$int_rate <- str_replace(loan_data$int_rate, "%", "")
loan_data$int_rate <- as.numeric(loan_data$int_rate)

loan_data$revol_util <- str_replace(loan_data$revol_util, "%", "")
loan_data$revol_util <- as.numeric(loan_data$revol_util)

# The variables issue_d, last_pymnt_d, earliest_cr_line, last_credit_pull_d are 
# stored as character which stored the date values. 

loan_data$issue_d <- as.Date(loan_data$issue_d, format = "%b-%d")
loan_data$last_pymnt_d <- as.Date(loan_data$last_pymnt_d, format = "%b-%d")

loan_data$earliest_cr_line <- paste("01-", loan_data$earliest_cr_line, sep="")
loan_data$earliest_cr_line <- as.Date(loan_data$earliest_cr_line, format = "%d-%b-%y")
loan_data$last_credit_pull_d <- as.Date(loan_data$last_credit_pull_d, format = "%b-%d")

# Extract the Month & Year and add is as a new variable to use for any further analysis.

install.packages("lubridate")
library(lubridate)
issued_year <- data.frame(issued_year = year(loan_data$issue_d))
loan_data <- cbind(loan_data, issued_year)
issued_month <- data.frame(issued_month = month(loan_data$issue_d))
loan_data <- cbind(loan_data, issued_month)
# Convert the values for these columns as factors.
loan_data$issued_year <- as.factor(loan_data$issued_year)
loan_data$issued_month <- as.factor(loan_data$issued_month)

########################
#Univariate analysis#
########################
View(loan_summary)

str(loan_data)
# id & member_id variables are unique and represents the unique identity for the user. 
# Ignoring these variables.

# loan_amnt variable indicates the amount of the loan applied for by the borrower.
# Let's draw some plots to understand the distribution of this variable.

# Let's draw a barplot on the loan_amt variable and see if it gives any insights.
library(ggplot2)
# Using table method to get the count of each loan amount. 
barplot(table(loan_data$loan_amnt))
# Barplot was little difficult to understand what is the distribution of the data. 
# Let's draw Histogram and see if it's easy to understand the distribution of the data.
hist(loan_data$loan_amnt, breaks=30, col = "red", xlab = "Loan Amount", ylab = "No of people applied", main = "Distribution of Loan Amount")

# histogram was much useful and it explains that most of the distribution of the data 
# is below $10,000 amount. Which means most of the people are applying for the loan amount
# less than $10,000.

# let's draw the hist plot for funded_amnt & funded_amnt_inv
hist(loan_data$funded_amnt, breaks=30, col = "red", xlab = "Loan Amount", main = "Distribution of funded_amnt")
hist(loan_data$funded_amnt_inv, breaks=30, col = "red", xlab = "Loan Amount", main = "Distribution of funded_amnt_inv")

# term variable The number of payments on the loan. From the above, we knew that 
# the distinct values for this variable are 36 & 60. 
# Let's find out how many loans were given for which term.
table(loan_data$term)
# From the above, it seems that 29096 loans were given for 36 months term and 10621 
# were given for 60
barplot(table(loan_data$term), main="Loan term Distribution", xlab="Loan Terms", ylab = "Count of loans given",col = "red")

# int_rate is the Interest Rate on the loan. 
table(loan_data$int_rate)
barplot(table(loan_data$int_rate), main="Distribution of Interest Rate", xlab="Interest rate in %", ylab = "Count of loans given",col = "red")

hist(loan_data$int_rate, breaks=30, col = "red", xlab = "Interest rate in %", ylab = "Count of loans given" ,main = "Distribution of Interest Rate")

summary(loan_data$int_rate)
# From the summary, we can understand min interest rate, max interest rate etc.

# installment is the monthly installment in $
hist(loan_data$installment, breaks=30, col = "red", xlab = "Installment in $", ylab = "Count of loans given" ,main = "Distribution of installment in $")

# home_ownership
table(loan_data$home_ownership)

# annual_inc is the annual income reported by the borrower. Let's draw histogram 
# and boxplot and see if it makes any sense about this variable.
hist(loan_data$annual_inc, breaks=30, col = "red")
boxplot(loan_data$annual_inc)
#Unfortunately, it was very difficult to understand from historgram and boxplot. Let's use summary and see if we can find anything.
summary(loan_data$annual_inc)

# verification_status
table(loan_data$verification_status)

# issue_d
# loan_status is the Current status of the loan
table(loan_data$loan_status)
# This explains the distribution of loan repayment status of the borrowers. 
#Let's find out the depenency with other variables.

# pymnt_plan - Indicates if a payment plan has been put in place for the loan
table(loan_data$pymnt_plan) 
#This shows that none of the users are having a payment plan put in place. 
#This variable does not provide any info.

# purpose - A category provided by the borrower for the loan request.
purpose_data <- as.data.frame(table(loan_data$purpose))
ggplot(purpose_data, aes(x=purpose_data$Var1, y=purpose_data$Freq)) + geom_bar(stat="identity", fill="red") + coord_flip()

# addr_state
loan_addrstate_data <- as.data.frame(table(loan_data$addr_state))
ggplot(loan_addrstate_data, aes(x=loan_addrstate_data$Var1, y=loan_addrstate_data$Freq)) + geom_bar(stat="identity", fill="red") + coord_flip()
# From this barplot, we can see that most of the loans were given to CA state.

# delinq_2yrs	The number of 30+ days past-due incidences of delinquency in the 
# borrower's credit file for the past 2 years
# inq_last_6mths
table(loan_data$inq_last_6mths)
boxplot(loan_data$inq_last_6mths)
# From the Boxplot, it appears that 75% of the loan requestors were not having more than
# 3 credit check inquiries in last 6 months. 
# Which helps to understand that 75% of the requestors applied for the loans less 
# than 3 times.

# mths_since_last_delinq - The number of months since the borrower's last delinquency.
as.data.frame(table(loan_data$mths_since_last_record))
boxplot(loan_data$mths_since_last_delinq, horizontal=TRUE)
hist(loan_data$mths_since_last_delinq, breaks=30, col = "red", xlab = "mths_since_last_delinq", ylab = "Count of people" ,main = "Distribution of mths_since_last_delinq")

# open_acc - The number of open credit lines in the borrower's credit file.
open_accts_data <- as.data.frame(table(loan_data$open_acc))
summary(open_accts_data)
boxplot(loan_data$open_acc)
hist(loan_data$open_acc, breaks=60, col = "red", xlab = "mths_since_last_delinq", ylab = "Count of people" ,main = "Distribution of mths_since_last_delinq")


# application_type
table(loan_data$application_type) #This shows that all of the applications are Individual.

# With the understandings from Univariate analysis, let's see what can we derive using
# Bivariate analysis.
########################
# Bivariate analysis#
########################
str(loan_data)

########## Annual income vs Loan Status ##########
table(loan_data$loan_status) #Charged Off - 5627, Current - 1140, Fully Paid - 32950
boxplot(loan_data$annual_inc) 
#This did show a box plot whcih was not useful to understand. 
#Let's see how the data is distributed.

summary(loan_data$annual_inc) # 3rd Qu. - 82300. Let's find out how many outliers exists. In other words, find out how many people exists with annual income higher than more than 3rd Quartile.
annual_incomegreater_3Qu <- subset(loan_data,loan_data$annual_inc>82300)
length(annual_incomegreater_3Qu$member_id) # So there are about 9929 people having annual income greater than 82300. 
summary(annual_incomegreater_3Qu$annual_inc) # 3rd Qu - 132000
annual_incomegreater_3Qu <- subset(loan_data,loan_data$annual_inc>132000)
summary(annual_incomegreater_3Qu$annual_inc) # 3rd Qu - 200000

# Now plot the graph and see how it would looks like. 
ggplot(loan_data, aes(loan_data$loan_status, loan_data$annual_inc)) + geom_boxplot() + ylim(0,200000) +
  labs(title = "Annual income vs Loan Status", x = "Loan Status", y = "Annual income") 
#It removed 586 rows which means we excluded these many people from the dataset.

########## Verification vs Loan Status ##########
ggplot(loan_data, aes(x=factor(loan_data$verification_status), fill = loan_data$loan_status)) +
  geom_bar(position = "dodge") + 
  labs(title = "Verification vs Loan Status",
       x = "Verification Status",
       y = "Count")

########## Grade vs Status ##########
ggplot(loan_data, aes(x=factor(loan_data$grade), fill = loan_data$loan_status)) + 
  geom_bar(position = "dodge") +
  labs(title = "Grade vs Status",
       x = "Grade",
       y = "Count")

########## Let's find out loan taken in every month by borrowers ##########

ggplot(loan_data, aes(loan_data$issued_month, fill = factor(loan_data$loan_status))) + 
  geom_histogram(stat="count", bandwidth = 10) + 
  labs(title = "Issue DMT and frequency",
       x = "Issued per Month",
       y = "Count")


########## loan_data Amount By Term among the data set ########## 
ggplot(loan_data, aes(loan_data$term,loan_data$loan_amnt)) + geom_boxplot(aes(fill = loan_data$term)) +
  labs(title = "loan_data amount by term",
       x = "Term",
       y = "loan_data amount")

########## Interest Rate by Grade among the data set ##########
ggplot(loan_data, aes(loan_data$grade,loan_data$int_rate)) + geom_boxplot(aes(fill = grade)) +
  labs(title = "Interest rate by grade",
       x = "Grade",
       y = "Interest rate")

########## Lending amount per month among the data set ##########
library(dplyr)
lending_amt = loan_data %>% 
  select(issued_month, loan_amnt) %>%
  group_by(issued_month) %>%
  summarise(Amount = sum(loan_amnt))

summary(lending_amt)
lending_amt

ggplot(lending_amt, aes(x = issued_month, y = Amount)) + geom_point() + 
  labs(title = "loan_data amount issued by month",
       x = "Issued Month",
       y= "Total Amount")

########## loan_data Status by Grade among the data set ##########
ggplot(loan_data, aes(loan_data$grade, fill = factor(loan_data$loan_status))) + geom_bar(position = "fill") + 
  labs(title = "loan_data status by grade",
       x = "Grade",
       y = "Rate")

########## Stacked Representation ##########
ggplot(loan_data, aes(loan_data$grade, fill = factor(loan_data$loan_status))) + geom_bar(position = "stack") + 
  labs(title = "loan_data status by grade",
       x = "Grade",
       y = "Rate")


########## loan_data disbursement growth rate ##########
amt_group_table = loan_data %>% 
  select(issued_month, loan_status, loan_amnt) %>% 
  group_by(issued_month, loan_status) %>% 
  summarise(Amount = sum(loan_amnt))

summary(amt_group_table)

ggplot(amt_group_table, aes(x = issued_month, y = Amount, col = factor(loan_status))) + geom_point() + 
  labs(title = "loan_data amount distribution among loan_data statuses",
       x = "Issued date",
       y = "Amount")

########## Annual Income by Grade#################
ggplot(loan_data, aes(grade,annual_inc)) + geom_boxplot() + ylim(0,200000) +
  labs(title = "Annual Income by Grade",
       x = "Grade",
       y = "Annual income") #Excluded 586 records

########## Fully paid vs Charged Off loan_datas excluding "on going" ########## 
loan_data2 <- subset(loan_data, loan_data$loan_status == "Fully Paid" | loan_data$loan_status == "Charged Off")
table(loan_data2$loan_status)
loan_data2$is_good = factor(ifelse(loan_data2$loan_status == "Fully Paid",1,0))
str(loan_data2$is_good)

########## Segmented Bivariate Analysis - loan_data disbursement Vs loan_data Status and Grade ##########
loan_datad_group_table = loan_data %>% 
  select(loan_status, loan_amnt, grade) %>% 
  group_by(loan_status, grade) %>% 
  summarise(Amount = sum(loan_amnt))

summary(loan_datad_group_table)

ggplot(loan_datad_group_table, aes(x = grade,y = Amount, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge") + geom_text(aes(label = Amount), position= position_dodge(width=0.9), vjust=-.5, color="black") +
  theme(legend.position = "bottom") +
  labs(title = "loan_data amount distribution Vs loan_data Status per Grades",
       x = "Grades",
       y = "Amount")

########## Segmented Bivariate Analysis - loan_data disbursement Vs Verification Status and loan_data Status ##########
loan_datad_group_table = loan_data %>% 
  select(loan_status, loan_amnt, verification_status) %>% 
  group_by(loan_status, verification_status) %>% 
  summarise(Amount = sum(loan_amnt))

summary(loan_datad_group_table)

ggplot(loan_datad_group_table, aes(x = verification_status,y = Amount, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge") + geom_text(aes(label = Amount), position= position_dodge(width=0.9), vjust=-.5, color="black") +
  theme(legend.position = "bottom") +
  labs(title = "loan_data amount distribution Vs loan_data Status per Grades",
       x = "Grades",
       y = "Amount")

